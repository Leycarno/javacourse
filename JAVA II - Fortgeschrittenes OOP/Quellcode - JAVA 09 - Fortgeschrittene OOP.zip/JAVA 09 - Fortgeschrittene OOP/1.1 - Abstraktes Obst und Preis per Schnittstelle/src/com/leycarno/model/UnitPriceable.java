package com.leycarno.model;

public interface UnitPriceable {

    int getAmount();

    float getUnitPrice();

}
