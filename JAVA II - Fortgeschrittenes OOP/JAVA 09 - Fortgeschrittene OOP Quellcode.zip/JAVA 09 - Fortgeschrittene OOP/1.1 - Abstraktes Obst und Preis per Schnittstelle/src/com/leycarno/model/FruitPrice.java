package com.leycarno.model;

public interface FruitPrice {

    float getUnitPrice();
}
