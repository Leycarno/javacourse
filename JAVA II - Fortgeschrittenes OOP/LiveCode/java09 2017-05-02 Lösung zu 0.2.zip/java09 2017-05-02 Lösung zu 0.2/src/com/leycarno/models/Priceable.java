package com.leycarno.models;

public interface Priceable {

    float getUnitPrice();

}
