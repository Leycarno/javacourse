package com.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Car car1 = new Car("Polo");
        Car car2 = new Car("Golf");

        // car1.setType("Polo");
        // car2.setType("Golf");

        String type = car1.getType();
        type = "Irgendwas";

        System.out.println(car1.getType());
        System.out.println(car2.getType());


    }
}
