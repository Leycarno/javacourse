package com.example;

public class Car {

    private String type;

    // Konstruktor
    public Car(String type) {
        this.setType(type);
    }

    private void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return this.type;
    }

}
