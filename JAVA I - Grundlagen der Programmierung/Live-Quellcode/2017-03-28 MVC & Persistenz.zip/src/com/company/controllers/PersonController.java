package com.company.controllers;

import com.company.services.PersonService;
import com.company.views.PersonView;

public class PersonController {

    private PersonService personService = new PersonService();
    private PersonView personView = new PersonView();

    public void run() {

        String name = personView.receiveString("Bitte einen Namen eingeben");
        personService.createPerson(name);

        personView.showPeople(personService.getPeople());

        try {
            personService.store("test.json");
        } catch (Exception ex) {
            System.err.println(ex);
        }
    }

}
