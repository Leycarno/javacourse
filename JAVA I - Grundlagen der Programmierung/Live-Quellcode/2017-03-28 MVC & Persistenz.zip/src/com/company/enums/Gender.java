package com.company.enums;

public enum Gender {

    MALE, FEMALE, OTHER

}
