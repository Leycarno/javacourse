package com.company;

import com.company.controllers.PersonController;
import com.company.package_public.A;
// import com.company.package_public.B;

public class Main {

    public static void main(String[] args) {

        PersonController controller = new PersonController();
        controller.run();

        A a = new A();
        // a.b.doSomething(); // geht nicht
        // B b = new B(); geht nicht...

    }

}
