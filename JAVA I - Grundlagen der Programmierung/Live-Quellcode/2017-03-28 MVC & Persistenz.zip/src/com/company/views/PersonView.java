package com.company.views;

import com.company.enums.Gender;
import com.company.models.Person;

import java.util.ArrayList;
import java.util.Scanner;

public class PersonView {

    public String receiveString(String label) {

        System.out.println(label);

        Scanner scanner = new Scanner(System.in);
        String name = scanner.nextLine();

        return name;
    }

    public void showPeople(ArrayList<Person> people) {
        for (Person p : people) {
            System.out.println(p.getName());
        }
    }

    public Gender receiveGenderByInt() {
        System.out.println("Bitte Geschlecht auswählen");

        int i = 0;

        for (int x = 0; x < Gender.values().length; x++) {
            Gender g = Gender.values()[x];
            System.out.println("" + i++ + ". " + g);
        }

        i = 0;

        for (Gender g : Gender.values()) {
            System.out.println("" + i++ + ". " + g);
        }

        Scanner scanner = new Scanner(System.in);
        int choice = scanner.nextInt();

        return Gender.values()[choice];
    }

    public Gender receiveGenderByString() {
        System.out.println("Bitte Geschlecht auswählen");

        int i = 1;
        for (Gender g : Gender.values()) {
            System.out.println(g);
        }

        Scanner scanner = new Scanner(System.in);
        String choice = scanner.nextLine();

        return Gender.valueOf(choice.toUpperCase());
    }

}
