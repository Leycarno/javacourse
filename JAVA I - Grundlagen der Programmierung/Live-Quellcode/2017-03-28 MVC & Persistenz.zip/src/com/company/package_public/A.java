package com.company.package_public;

public class A {

    public B b = new B();
}
