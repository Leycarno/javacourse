package com.company.package_public;

class B {

    public void doSomething() {

    }
}
