package com.company.services;

import com.company.models.Person;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class PersonService {

    ArrayList<Person> people = new ArrayList<>();

    public void store(String filename) throws IOException {
        ObjectMapper mapper = new ObjectMapper();
        mapper.writeValue(new File(filename), people);
    }

    public boolean createPerson(String name) {

        if (name.length() < 3)
            return false; // person wurde NICHT erstellt

        Person person = new Person();
        person.setName(name);

        people.add(person);

        return true; // Person wurde erstellt
    }

    public ArrayList<Person> getPeople() {
        return people;
    }
}
