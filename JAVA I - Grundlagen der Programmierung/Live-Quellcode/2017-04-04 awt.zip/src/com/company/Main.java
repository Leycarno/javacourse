package com.company;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Main {

    private static Frame frame = new Frame();
    private static Label label = new Label();
    private static TextField a = new TextField();
    private static TextField b = new TextField();
    private static Button button = new Button();
    private static Panel panel = new Panel();

    public static void main(String[] args) {
        createFrame();
        createLabel();
        createTextFields();
        createButton();

        createPanel();

        frame.setVisible(true);
    }

    private static void createButton() {
        button.setLabel("OK");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                label.setText("Button gedrückt");

                // simpler Taschenrechner (+)
                String ergStr;
                try {
                    int erg = Integer.parseInt(a.getText()) + Integer.parseInt(b.getText());
                    ergStr = "Ergebnis " + erg;
                } catch (Exception ex) {
                    ergStr = "ZAHLEN!!!";
                }
                label.setText(ergStr);

                frame.revalidate();
            }
        });
    }

    private static void createPanel() {
        panel.setLayout(new GridLayout(1, 4));

        panel.add(a);
        panel.add(b);
        panel.add(button);
        panel.add(label);

        Panel panel2 = new Panel();
        panel2.add(panel);
        frame.add(panel2);
    }

    private static void createTextFields() {
        //frame.add(a);
        //frame.add(b);
    }

    private static void createLabel() {
        label.setText("Ergebnis");
        label.setAlignment(Label.CENTER);
        //frame.add(label);
    }

    private static void createFrame() {
        frame.setSize(400, 400);
        frame.setLocation(800, 50);
        frame.setTitle("Hello AWT World");

        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                e.getWindow().dispose();
                System.exit(0); // wirklich auch Programm beenden
            }
        });
    }
}
