package com.company.controllers;

import com.company.services.CarService;
import com.company.views.CarView;

public class CarController {

    private CarService service = new CarService();
    private CarView view = new CarView();

    public void run() {
        String type = view.getTypeFromUser();
        try {
            service.createNewCar(type);
        } catch (Exception e) {
            view.showError(e.getMessage());
        }
    }

}
