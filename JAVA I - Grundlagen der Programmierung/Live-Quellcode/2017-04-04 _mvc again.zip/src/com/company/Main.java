package com.company;

import com.company.controllers.CarController;

public class Main {

    public static void main(String[] args) {

        CarController controller = new CarController();
        controller.run();

    }
}
