package com.company.views;

import java.util.Scanner;

public class CarView {

    Scanner scanner = new Scanner(System.in);

    public String getTypeFromUser() {
        System.out.print("Bitte einen Typen eingeben");

//        String type = scanner.nextLine();
//        return type;

        return scanner.nextLine();
    }

    public void showError(String message) {
        System.err.println(message);
    }
}
