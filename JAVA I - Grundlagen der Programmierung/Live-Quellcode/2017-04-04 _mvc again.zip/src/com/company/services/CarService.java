package com.company.services;

import com.company.models.Car;

import java.util.ArrayList;

public class CarService {

    private static final int[] FIX_NUMBERS = new int[] {2, 5, 7};

    private static ArrayList<Car> carList = new ArrayList<>();

    public void createNewCar(String type) throws Exception {
        if (type.length() < 3 && type.length() > 20) {
            throw new Exception("Bitte 3-20 Buchstaben verwenden!");
        }

        Car car = new Car();
        car.setType(type);

        carList.add(car);
    }

}
