package com.leycarno;

/**
 * Created by leyca on 14.03.2017.
 */
public class Program1 {

    public void run() {
        Person steffen = new Person("Steffen");
        Person wolf = new Person("Wolf");

        Car opel = null;
        for (int i = 0; i < 10; i++) {
            opel = new Car("Opel");
            System.out.println(Car.getBuilt());
        }

        System.out.println(opel);

        Car steffensAuto = steffen.getCar();
        System.out.println(steffensAuto);

        steffen.setCar(opel);
        System.out.println(steffensAuto);
        System.out.println(steffen.getCar());
//

        steffen.setMoney(100);
        steffen.pay(50);
        steffen.pay(200);

        System.out.println("Steffen hat "
                + steffen.getMoney()
                + " Euro!");

        System.out.println(steffen);
        System.out.println(steffen.getName());

        String bla = wolf.getName();
        System.out.println(bla);
    }

}
