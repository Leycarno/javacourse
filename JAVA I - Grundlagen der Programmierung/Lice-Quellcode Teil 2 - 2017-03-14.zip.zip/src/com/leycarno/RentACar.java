package com.leycarno;

public class RentACar {

    boolean useWhile = false; // otherwise use for-loop

    public void run() {

        Person person = new Person("Steffen");
        person.setMoney(1000);
        Car car = new Car("Porsche");
        car.setPricePerDay(300);

        person.setCar(car);

        if (useWhile) {
            useWhile(person, car);
        } else { // use for-loop
            useForLoop(person, car);
        }
    }

    private void useForLoop(Person person, Car car) {
        if (car.getPricePerDay() == 0) return;

        int days = (int) (person.getMoney() / car.getPricePerDay());
        float price = days * car.getPricePerDay();
        person.pay(price);

        for (int i = 1; i <= days; i++) {
            System.out.println("FOR: der " + i + " Tag vergeht...");
        }

    }

    private void useWhile(Person person, Car car) {
        int x = 1;
        while (person.getMoney() >= car.getPricePerDay()) {
            person.pay(car.getPricePerDay());
            System.out.println("WHILE: der " + x++ + " Tag vergeht...");
        }
    }
}
