package com.leycarno;

public class Person {

    private String name;
    private float money;
    private Car car;

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                ", money=" + money +
                '}';
    }

    public float getMoney() {
        return money;
    }

    public void setMoney(float money) {
        if (money >= 0) {
            this.money = money;
        } else {
            System.out.println("Soviel Geld hast du nicht!");
        }
    }

    public void pay(float price) {
        if (this.money - price < 0) {
            System.out.println("Soviel Geld hast du nicht!");
        } else {
            this.setMoney(this.money - price);
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public Person(String name) {
       this.name = name;
    }

}
