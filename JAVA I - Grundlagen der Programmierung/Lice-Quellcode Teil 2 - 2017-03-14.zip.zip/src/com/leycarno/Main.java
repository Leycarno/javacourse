package com.leycarno;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Welches Programm (1-2):");

        int option = 0;
        try {
            option = scanner.nextInt();
        } catch (Throwable th) {
            System.out.println("Es gibt nur 2 Programme");
            System.exit(0);
        }

        switch (option) {
            case 1:
                Program1 p = new Program1();
                p.run();
                break;

            case 2:
                RentACar rac = new RentACar();
                rac.run();
                break;

            default:
                System.out.println("Es gibt nur 2 Programme");
                break;

        }

        scanner.close();
    }
}
