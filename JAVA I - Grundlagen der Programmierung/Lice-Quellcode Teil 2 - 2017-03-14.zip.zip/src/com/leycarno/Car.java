package com.leycarno;

public class Car {

    private static int built;

    private String type;
    private float maxFuel;
    private float fuel;
    private float maxSpeed;
    private float pricePerDay;

    public float getPricePerDay() {
        return pricePerDay;
    }

    public void setPricePerDay(float pricePerDay) {
        this.pricePerDay = pricePerDay;
    }

    public Car(String type) {
        this.type = type;
        built++;
    }

    public static int getBuilt() {
        return built;
    }

    @Override
    public String toString() {
        return "Car{" +
                "type='" + type + '\'' +
                ", maxFuel=" + maxFuel +
                ", fuel=" + fuel +
                ", maxSpeed=" + maxSpeed +
                '}';
    }

    public float getMaxFuel() {
        return maxFuel;
    }

    public void setMaxFuel(float maxFuel) {
        this.maxFuel = maxFuel;
    }

    public float getFuel() {
        return fuel;
    }

    public void setFuel(float fuel) {
        this.fuel = fuel;
    }

    public float getMaxSpeed() {
        return maxSpeed;
    }

    public void setMaxSpeed(float maxSpeed) {
        this.maxSpeed = maxSpeed;
    }
}
