package com.leycarno.javacourse.java_07_json_files;

import com.leycarno.javacourse.java_07_json_files.controllers.MainController;

public class PersistenceMain {

    public static void main(String[] args) {

        MainController mainController = new MainController();
        mainController.run();

    }
}
