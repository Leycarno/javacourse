package com.leycarno.javacourse.java_08_awt;

import com.leycarno.javacourse.java_08_awt.views.MainView;

public class AwtMain {

    private static MainView mainView;

    public static void main(String[] args) {
        mainView = new MainView();
    }

}
