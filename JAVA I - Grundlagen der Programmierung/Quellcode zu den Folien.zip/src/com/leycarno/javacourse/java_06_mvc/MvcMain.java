package com.leycarno.javacourse.java_06_mvc;

import com.leycarno.javacourse.java_06_mvc.controllers.RefuelCarMvc;

public class MvcMain {

    public static void main(String[] args) {

        RefuelCarMvc refuelCar = new RefuelCarMvc();
        refuelCar.run();

    }
}
