package com.leycarno;

import com.leycarno.controllers.MainController;

public class Main {

    public static void main(String[] args) {

        MainController mainController = new MainController();
        mainController.run();

    }
}
