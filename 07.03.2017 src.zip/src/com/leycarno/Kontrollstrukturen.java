package com.leycarno;


import java.util.Scanner;

public class Kontrollstrukturen {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Wie Viele Versuche?");
        int maximaleVersuche = scanner.nextInt();

        if (maximaleVersuche > 1000) {
            System.out.println("Maximal 1000 Versuche?");
            System.exit(0);
        }

        int versuch = 1;
        int zufallsZahl;

        do {

            zufallsZahl = (int) (Math.random() * 11);
            System.out.println(zufallsZahl);

            if (zufallsZahl < 5) {
                System.out.println("Kleiner als die Mitte");
            } else if (zufallsZahl > 5) {
                System.out.println("Größer als die Mitte");
            } else {
                System.out.println("MITTE!");
                break; // Schleife beenden!
            }

        } while (versuch++ < maximaleVersuche); // && zufallsZahl != 5);

        // STRG + ALT + L


    }
}
