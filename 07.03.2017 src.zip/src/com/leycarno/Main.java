package com.leycarno;

public class Main {

    public static void main(String[] args) {

        System.out.print("Hello ");
        System.out.print("World");
        System.out.println("!");

        // eine interessante Information
        // ....

        /*
        lksjdlkn
        ksdk
         */

        System.out.print("\n\tNeue eingerückte Zeile?");

    }
}
