package com.leycarno;

public class Variablen {

    public static void main(String[] args) {
        int Zahl2 = 20;
        int Zahl3, Zahl4;

        // primitive Datentypen


        byte aByte = 127;
        short aShort = 6400; // -32.768 ... 32.787

        float f = 2.4f;
        double d = 2.4;

        char c = 'A';

        int Zahl; // Definition
        Zahl = 10; //Initialisierung
        System.out.println(Zahl);

        boolean b = true;
        System.out.println("Ausgabe eines boolean: " + b);

        int Zahl5 = 30, Zahl6 = 40;
        System.out.println("Ausgaben einer Berechung: " + Zahl5 + Zahl6);
        System.out.println("Ausgaben einer Berechung: " + (Zahl5 + Zahl6));

    }

}
