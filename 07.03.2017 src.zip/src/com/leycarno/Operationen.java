package com.leycarno;

public class Operationen {

    public static void main(String[] args) {

        int x = 3, y = 5;

        int result = x + y;
        System.out.println("Ergebnis aus " + x + " + " + y + " = " + result);

        int ergebnis = x % y;
        System.out.println(ergebnis);

        // -------------------------------

        boolean xIsBiggerThanY = x > y;
        boolean yIsBiggerThanX = !xIsBiggerThanY;






    }

}
